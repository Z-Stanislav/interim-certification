package ru.yandex.praktikum.model.constants;

public class Color {
    public static final String COLOR_RED = "red";
    public static final String COLOR_GREEN = "green";
}
