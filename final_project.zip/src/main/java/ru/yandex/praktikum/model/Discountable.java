package ru.yandex.praktikum.model;

public interface Discountable {
    Double getDiscount();
}
